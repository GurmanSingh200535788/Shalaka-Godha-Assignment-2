module com.example.newsfinder {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.kordamp.bootstrapfx.core;
    requires com.google.gson;

    opens com.example.newsfinder to javafx.fxml;
    exports com.example.newsfinder;

}